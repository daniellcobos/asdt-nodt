function mensaje() {
    alert('ahora voy aca');
}

